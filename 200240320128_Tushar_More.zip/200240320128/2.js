function Validation(){

  let Password=document.querySelector('#Password').value;
  let Username=document.querySelector('#Username').value;

  if(Username=="" || Password==""){
    return false;
  }

  let newElement1=document.createElement('div');
  let newElement2=document.createElement('div');

  newElement1.textContent=Username;
  newElement2.textContent=Password;
  let parent =document.querySelector('.result');
  let maindiv=document.querySelector('.Form').style.visibility="hidden";
  parent.appendChild(newElement1);
  parent.appendChild(newElement2);

}
